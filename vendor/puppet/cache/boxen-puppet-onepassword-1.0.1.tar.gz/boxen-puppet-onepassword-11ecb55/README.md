# 1Password Puppet Module for Boxen

## Usage

```puppet
include onepassword
```

## Required Puppet Modules

* boxen
* stdlib
